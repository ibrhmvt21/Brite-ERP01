package com.events.tests.functionality_tests;

import com.events.pages.LoginPage;
import org.testng.annotations.Test;

public class searchFunctionalityTest {

	  @Test
	  public void TestCase1() {

	  }
	  
	 
	  @Test
	  public void TestCase2() {
	  }
	  @Test
	  public void TestCase3() {
	  }
}
