package com.events.pages;



public class eventsReportingLocators {




}
